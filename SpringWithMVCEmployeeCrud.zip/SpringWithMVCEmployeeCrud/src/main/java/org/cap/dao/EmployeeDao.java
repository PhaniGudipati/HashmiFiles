package org.cap.dao;

import org.cap.entities.Employee;

public interface EmployeeDao {

    Employee findEmployeeById(int id);

    Employee createEmployee(Employee user);

    Employee updateEmployee(String username);

	void deleteEmployee(int id);
}
