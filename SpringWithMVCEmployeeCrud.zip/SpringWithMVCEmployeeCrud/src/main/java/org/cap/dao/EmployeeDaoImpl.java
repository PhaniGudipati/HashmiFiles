package org.cap.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.entities.Employee;
import org.springframework.stereotype.Repository;
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
    @PersistenceContext
    private EntityManager em;
    public EmployeeDaoImpl(){
    }
    @Override
    public Employee findEmployeeById(int id) {
      Employee u= em.find(Employee.class,id);
      return u;
    }
    @Override
    public Employee createEmployee(Employee user){
        user=em.merge(user);
        return user;
    }
    @Override
    public Employee updateEmployee(String name) {
        Employee user=new Employee();
        user.setEmpName(name);
        user=em.merge(user);
        return user;
    }
	@Override
	public void deleteEmployee(int id) {
		
	}
}
