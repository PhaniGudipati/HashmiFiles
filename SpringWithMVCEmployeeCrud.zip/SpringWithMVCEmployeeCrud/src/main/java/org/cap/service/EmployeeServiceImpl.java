package org.cap.service;

import javax.transaction.Transactional;

import org.cap.dao.EmployeeDao;
import org.cap.entities.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service // @Component,@Repository
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;

	@Override
	public Employee findEmployeeById(int id) {
		Employee user = dao.findEmployeeById(id);
		return user;
	}

	@Override
	public Employee createEmployee(Employee user) {
		// transaction opened by spring
		user = dao.createEmployee(user);
		// transaction closed by spring
		return user;
	}

	@Override
	public Employee updateEmployee(String name) {
		return dao.updateEmployee(name);
	}

	@Override
	public void deleteEmployee(int id) {
		dao.deleteEmployee(id);
	}

}
