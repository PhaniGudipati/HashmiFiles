package org.cap.service;

import org.cap.entities.Employee;

public interface EmployeeService {
	Employee findEmployeeById(int id);

	Employee createEmployee(Employee user);

	Employee updateEmployee(String name);

	void deleteEmployee(int id);
}
