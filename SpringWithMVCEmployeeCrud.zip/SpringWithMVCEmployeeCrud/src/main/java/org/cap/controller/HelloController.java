package org.cap.controller;
import java.util.HashMap;
import java.util.Map;
import org.cap.entities.Employee;
import org.cap.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	@Autowired
	private EmployeeService service;

	private int i = 0;
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		i++;
		ModelAndView mv = new ModelAndView("hellopage", "message",
				"Hello request count=" + i);
		return mv;
	}
	@RequestMapping(value = "/userdetails", method = RequestMethod.GET)
	public ModelAndView userDetails(@RequestParam("id") int id) {
		Employee user = service.findEmployeeById(id);
		if (user == null) {
			ModelAndView mv = new ModelAndView("usernotfound", "id", id);
			return mv;
		}
		Map<String, Object> modelMap = new HashMap<>();
		modelMap.put("id", id);
		modelMap.put("name", user.getEmpName());
		ModelAndView mv = new ModelAndView("userdetails", modelMap);
		return mv;
	}
	@RequestMapping("/getdetails")
	public ModelAndView detailsForm() {
		return new ModelAndView("detailsform", new HashMap<>());
	}
	@RequestMapping("/createuser")
	public ModelAndView createUserForm() {
		ModelAndView mv = new ModelAndView("createuser");
		return mv;
	}
	@RequestMapping("/createprocess")
	public ModelAndView createProcess(@RequestParam String name) {
		Employee user = service.updateEmployee(name);
		Map<String, Object> map = new HashMap<>();
		map.put("id", user.getEmpId());
		map.put("name", user.getEmpName());
		ModelAndView mv = new ModelAndView("usercreated", map);
		return mv;
	}}