package org.cap.controller;
import org.cap.dao.UserNotFoundException;
import org.cap.entities.Employee;
import org.cap.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserRestController {
    @Autowired
    private EmployeeService employeeService;
    @RequestMapping(value = "/user/find/{id}",
            method = RequestMethod.GET,
            produces = "application/json")
    public ResponseEntity<Employee> findUser(@PathVariable("id") int id) {
        Employee user = employeeService.findEmployeeById(id);
        if (user == null) {
            throw new UserNotFoundException("user not found for id=" + id);
        }
        ResponseEntity<Employee> responseEntity = new ResponseEntity<>(user, HttpStatus.OK);
        System.out.println("response entity=" + responseEntity);
        return responseEntity;
    }
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> userNotFound(UserNotFoundException e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }
    @RequestMapping(value = "/user/create",
            method = RequestMethod.POST,
            consumes = {"application/json"},
            produces = "application/json")
    public ResponseEntity<Boolean> createUser(@RequestBody Employee user) {
        user = employeeService.createEmployee(user);
        ResponseEntity<Boolean> responseEntity = new ResponseEntity<Boolean>(true, HttpStatus.OK);
        System.out.println("response entity=" + responseEntity);
        return responseEntity;
    }
}
