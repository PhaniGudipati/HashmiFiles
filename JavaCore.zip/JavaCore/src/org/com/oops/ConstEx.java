package org.com.oops;

public class ConstEx {
	int a;
	ConstEx() {
		System.out.println("Default constructor");
	}

	ConstEx(int a, int b) {
		System.out.println((a + b) + " " + "am from param constructor");
	}

	public static void main(String[] args) {
		ConstEx con = new ConstEx();
		ConstEx cons = new ConstEx(10, 20);
		System.out.println(con);
		System.out.println(con.toString());

	}

}
