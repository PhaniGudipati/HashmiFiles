package org.com.oops;

public class Clienttt {

	public static void main(String[] args) {
EncapsExa e=new EncapsExa();
e.setEmpId(1233);
	e.setEmpName("Phani");
	e.setSalary(123456.22f);
	System.out.println(e.getEmpId());
	System.out.println(e.getEmpName());
	System.out.println(e.getSalary());
	

	}

}
