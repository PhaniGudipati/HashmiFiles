package org.com.oops;

public class MultiEx extends Thread {
	@Override
	public void run() {
		
		Thread.currentThread().setPriority(10);
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setName("Ibm");
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread());
	
		for(int i=0;i<=10;i++) {
			System.out.println("Child Thread");
		}
		
	}

	public static void main(String[] args) throws InterruptedException {
		Thread.currentThread().setPriority(10);
		//System.out.println(Thread.currentThread().getPriority());
		//Thread.currentThread().setName("Ibm");
		//System.out.println(Thread.currentThread());
		MultiEx m=new MultiEx();//Thread sheduler//0-10
		
		//Thread t=new Thread(m);
		
		m.start();
		//m.sleep(2000);
		//m.join();
		for(int i=0;i<=10;i++) {
			
			System.out.println("Parent Thread");
		}

	}

	
}
