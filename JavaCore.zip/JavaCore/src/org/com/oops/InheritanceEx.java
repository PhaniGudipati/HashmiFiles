package org.com.oops;

import dummy.thresd.withsync.A;
import dummy.thresd.withsync.B;

class A{
	int a=100;
	public void addition() {
		int  a=10;
		int b=20;
		System.out.println(a+b);
	}
	
}
class D extends A{
	int x=300;
	public void div(int a, int b) {
		System.out.println(a/b);
		
	}
	
}
class B extends D{
	int d=2000;
	public static int mul() {
		int a=100;
		int b=2;
		return a*b;
	}
}

public class InheritanceEx extends B{
	int c=300;
	public void sub(int a,int b) {
		System.out.println(a-b);
	}

	public static void main(String[] args) {
	InheritanceEx in=new InheritanceEx();
	System.out.println(in.a);
	in.addition();
	System.out.println(in.c);
	in.sub(100, 50);
	
	System.out.println(B.mul());

	}

}
