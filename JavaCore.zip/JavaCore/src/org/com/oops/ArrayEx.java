package org.com.oops;

public class ArrayEx {
	public static void main(String[] args) {
		
	
	int[] arr=new int[3];
	arr[0]=80;
	arr[1]=90;
	arr[2]=100;
	System.out.println(arr[2]);
	
	int[][] array= {{1,2,3},{4,5,6}};
	System.out.println(array[1][1]);
	}
	}
// how we can fetch All the elements from array?