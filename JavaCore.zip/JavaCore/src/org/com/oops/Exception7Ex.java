package org.com.oops;

import java.util.Scanner;

class InvalidCredentials extends Exception{
	InvalidCredentials(String msg){
		super(msg);
		
	}
}

public class Exception7Ex {
	public static void validation(String uname,String password) throws InvalidCredentials {
		if(uname.equals("Ibm")&&password.equals("Ibm123"))
			System.out.println("Login Success!!!");
		else 
			throw new InvalidCredentials("Invalid Credentials !!!!");
	}

	public static void main(String[] args) throws InvalidCredentials {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter UserName!");
		String uname=scan.next();
		System.out.println("Enter Password!");
		String password=scan.next();
		Exception7Ex.validation(uname,password);
		

	}

}
