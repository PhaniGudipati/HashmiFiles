package org.com.oops;

import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
	int a[][]= {{10,20},{30,40,50}};
	
		
		System.out.println(a[1][2]);
	}

}
