package org.com.oops;

public class StringExa {

	public static void main(String[] args) {
		String str1="animal";
		String str2="animal";
		str1.concat("hello");
		System.out.println(str1.toUpperCase());
		
		System.out.println(str1==str2);
		System.out.println(str1.equals(str2));
		System.out.println(str1.compareTo(str2));
		//+ve if obj1 comes after obj2
		//-ve if obj1 comes before obj2
		//0 if both are equal
		
		String str3=new String("Hello");
		String str4=new String("Hello");
		
		System.out.println(str3==str4);
		System.out.println(str3.equals(str4));
		System.out.println(str3.compareTo(str4));
		
		StringBuilder sb=new StringBuilder("Hello");
		sb.append("Haiii");
		System.out.println(sb);
		
	}

}
