package org.com.oops;
 class Alpha{
	final int a=10;
	
	public  void display() {
		System.out.println("Hello");
	}
	
	
}



public class ThisSuperEx extends Alpha {
	
	@Override
	public void display() {
		System.out.println("Haiii");
	}

	public static void main(String[] args) {
		ThisSuperEx t=new ThisSuperEx();
		System.out.println(t.a);
		t.display();

	}

}
