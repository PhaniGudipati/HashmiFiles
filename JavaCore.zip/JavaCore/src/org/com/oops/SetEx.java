package org.com.oops;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class SetEx {

	public static void main(String[] args) {
		ReverseOrder r = new ReverseOrder();
		TreeSet<String> h = new TreeSet<String>(r);

		h.add("Hello");// syso(hello.compareTo(Raghav))
		h.add("Raghav");
		h.add("Phani");
		h.add("Kumar");
		h.add("Abhi");
		System.out.println(-"Hello".compareTo("Raghav"));
		System.out.println(h);
		Iterator itr = h.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}

class ReverseOrder implements Comparator<String> {
	@Override
	public int compare(String a, String b) {
		return -a.compareTo(b);

	}

}
