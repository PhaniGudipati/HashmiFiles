package org.com.oops;
class Abc{
	public void display() {
		System.out.println("Am from Parent class");
		
	}
	
	
}

public class MethodOverRidingex extends Abc {
	@Override
	public void display() {
		System.out.println("am from child class");
	}

	public static void main(String[] args) {
		MethodOverRidingex meth=new MethodOverRidingex();
		meth.display();
		
	}

}
