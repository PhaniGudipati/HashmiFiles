package org.com.oops;

public class MethOLoadingEx {
	public void addition(int a,int b) {
		System.out.println(a+b);
	}
	public void addition(float a ,float b) {
		System.out.println(a+b);
	}
	public void addition(int a,int b,int c) {
		System.out.println(a+b+c);
	}
	public void addition(int a,float b) {
		System.out.println(a+b);
	}
	public void addition(float a,int b) {
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		MethOLoadingEx meth=new MethOLoadingEx();
		meth.addition(10, 20);
		meth.addition(10.2f, 10.8f);
		meth.addition(10, 20, 30);
		meth.addition(10, 20.0f);
		meth.addition(20.0f, 20);
		
		

	}

}
