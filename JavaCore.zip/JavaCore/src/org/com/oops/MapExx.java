package org.com.oops;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapExx {

	public static void main(String[] args) {
		TreeMap<Integer,String> h=new TreeMap();
		h.put(106, "Sharuk");
		h.put(102, "Salman");
		h.put(103, "Hruthik");
		h.put(101, "Phani");
		h.put(105, "Hashmi");
		h.put(102, "Sharuk");
		System.out.println(h);
		Set<Integer> keys=h.keySet();
		Iterator<Integer> itr=keys.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		Set<Entry<Integer,String>> s=h.entrySet();
		Iterator<Entry<Integer,String>> itr1=s.iterator();
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}
	}

}
