package org.com.oops;

public class WrapEx {

	public static void main(String[] args) {
		
	
		
		String str="100";
		String str1="200";
		
		int x=Integer.parseInt(str);
		int y=Integer.parseInt(str1);
		System.out.println(x+y);
		
		Integer z=Integer.parseInt(str1);
		System.out.println(str1 + "100");
		

	}

}
