package org.com.oops;

import java.util.Vector;

public class CollExa {

	public static void main(String[] args) {
		Vector a=new Vector();
		a.add("Phani");
		a.add("Hashmi");
		a.add(1000);
		a.add(123.3456f);
		a.add("Hashmi");
		a.add("Phani");
		a.add("Hashmi");
		a.add(1000);
		a.add(123.3456f);
		a.add("Hashmi");
		a.add(12345);
		
		System.out.println(a.capacity());//10=(cc*3/2)+1=16
	
		

	}

}
