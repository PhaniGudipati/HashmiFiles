package org.com.oops;
class Parent{
	int a=123;
	Parent(){
		System.out.println("Parent class Default constrictor");
		
	}
	public void m1() {
		System.out.println("am from parent class m1 method");
	}
}

public class ThisSuperExa extends Parent {
	int a=234;
 ThisSuperExa() {
		System.out.println(this.a);
		System.out.println(super.a);
		this.m1();
		super.m1();
	}
 ThisSuperExa(String name){
	 
	 this();
	 System.out.println("param const" + name);
 }
 public void m1() {
	 System.out.println("am from child class  "+super.a+a);
}

	public static void main(String[] args) {
		ThisSuperExa obj=new ThisSuperExa();
		System.out.println(obj.a);
		ThisSuperExa obj2=new ThisSuperExa("Phani");
		

	}

}
