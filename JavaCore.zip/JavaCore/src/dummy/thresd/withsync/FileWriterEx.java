package dummy.thresd.withsync;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterEx {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("abc.txt");
		fw.write(100);
		fw.write("\n");
		fw.write("hello");
		char ch[]= {'a','b','c'};
		fw.write("\n");
		fw.write(ch);
		fw.close();
//it will allow only characters
	}

}
