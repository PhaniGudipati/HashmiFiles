package dummy.thresd.withsync;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterEx {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("xyzxyzzz");
		PrintWriter pw=new PrintWriter(fw);
		pw.println(1000);
		pw.println(false);
		pw.println("Phani");
		pw.println('b');
		fw.flush();
		pw.close();
		fw.close();

	}

}
