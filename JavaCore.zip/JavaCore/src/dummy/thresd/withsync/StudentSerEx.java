package dummy.thresd.withsync;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class StudentSerEx {
	public static void main(String[] args) throws IOException {
		Student std=new Student(100, "Phani", 10000);
		FileOutputStream out=new FileOutputStream("kakaa.txt");
		ObjectOutputStream obj=new ObjectOutputStream(out);
		obj.writeObject(std);
		System.out.println("serialization is done");
	}

}
