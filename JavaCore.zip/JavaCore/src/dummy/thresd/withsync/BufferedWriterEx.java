package dummy.thresd.withsync;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterEx {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("def.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write(1234);
		bw.newLine();
		bw.write("Phani");
		bw.write("\n");
		char ch[]= {'a','b','c'};
		bw.write(ch);
		fw.flush();
		bw.close();
		fw.close();

	}

}
