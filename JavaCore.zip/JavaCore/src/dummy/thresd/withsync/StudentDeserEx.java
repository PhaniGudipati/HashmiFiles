package dummy.thresd.withsync;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class StudentDeserEx {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileInputStream in=new FileInputStream("kakaa.txt");
		ObjectInputStream obj=new ObjectInputStream(in);
		Student std=(Student) obj.readObject();
		System.out.println(std);
		System.out.println("Deserialization is done");
	}

}
