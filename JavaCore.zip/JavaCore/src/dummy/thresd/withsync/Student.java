package dummy.thresd.withsync;

import java.io.Serializable;

public class Student implements Serializable {
	private transient int stdId;
	private String stdName;
	private int stdFee;
	
	public Student(int stdId, String stdName, int stdFee) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.stdFee = stdFee;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public int getStdFee() {
		return stdFee;
	}
	public void setStdFee(int stdFee) {
		this.stdFee = stdFee;
	}
	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", stdFee=" + stdFee + "]";
	}
	

}
