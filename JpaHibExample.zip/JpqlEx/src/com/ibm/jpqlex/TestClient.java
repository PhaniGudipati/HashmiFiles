package com.ibm.jpqlex;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestClient {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("ibm");
EntityManager em=emf.createEntityManager();
em.getTransaction().begin();
//Employee emp=new Employee(123,"Chiranjeev",10000000);
//Employee emp1=new Employee(124,"Rakesh",20000000);
//Employee emp2=new Employee(125,"Sanket",30000000);
//Employee emp3=new Employee(126,"AbhiRami",40000000);
//em.persist(emp);
//em.persist(emp1);
//em.persist(emp2);
//em.persist(emp3);
//System.out.println("Inserted");
//em.getTransaction().commit();
//Query query=em.createQuery("select e from Employee e");
//List<Employee> emps=query.getResultList();
//for(Employee emp: emps) {
//	System.out.println(emp);
//}
//Query q=em.createQuery("update Employee set empSal=empSal+5000 where empSal>2000000");
//int result=q.executeUpdate();
//System.out.println(result + " Records updated");
Query q1=em.createQuery("delete from Employee e where e.empSal<30000000");
int result=q1.executeUpdate();
System.out.println(result+"deleted");
em.getTransaction().commit();
em.close();
emf.close();
	}

}
