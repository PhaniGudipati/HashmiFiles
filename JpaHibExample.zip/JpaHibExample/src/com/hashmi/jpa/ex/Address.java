package com.hashmi.jpa.ex;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Address {
	@Id
	private int doorno;
	private String colony;
	private String city;
	private String country;
	private String zipcode;
	public int getDoorno() {
		return doorno;
	}
	public void setDoorno(int doorno) {
		this.doorno = doorno;
	}
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public Address(int doorno, String colony, String city, String country, String zipcode) {
		super();
		this.doorno = doorno;
		this.colony = colony;
		this.city = city;
		this.country = country;
		this.zipcode = zipcode;
	}
	@Override
	public String toString() {
		return "Address [doorno=" + doorno + ", colony=" + colony + ", city=" + city + ", country=" + country
				+ ", zipcode=" + zipcode + "]";
	}
	

}
