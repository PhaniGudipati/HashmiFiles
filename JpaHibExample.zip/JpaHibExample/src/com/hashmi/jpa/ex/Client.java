package com.hashmi.jpa.ex;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Hashmi");
		EntityManager em=emf.createEntityManager();
		//ddl,dml begin commit ,dql
		em.getTransaction().begin();
//		User user=new User();//insert=persist,update=merge,delete=remove,select=find
//		user.setUserName("Phani");
//		Address a=new Address();
//		a.setDoorno(123);
//		a.setColony("Lb nagar");
//		a.setCity("Hyderabad");
//		a.setZipcode("xyz");
//		a.setCountry("India");
//		user.setAddress(a);
//		em.persist(user);
		//em.persist(a);
		User u=em.find(User.class, 1);
		System.out.println(u.getUserName());
		System.out.println("with lazy");
		System.out.println(u.getAddress().getCity());
		System.out.println("Inserted");
		em.getTransaction().commit();
		em.close();
		emf.close();//JPQL - select u from User u
		

	}//association

}
