package com.ibm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ibm.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
 private EntityManager entityManager;
 public EmployeeDaoImpl() {
	 entityManager =JPAUtil.getEntityManager();
 }
	@Override
	public Employee getEmployeeById(int id) {
		Employee employee=entityManager.find(Employee.class,id);
		return employee;
	}

	@Override
	public String addEmployee(Employee employee) {
		entityManager.persist(employee);
		return "Employee Inserted Successfully";
	}

	@Override
	public String removeEmployee(Employee employee) {
		entityManager.remove(employee);
		return "Employee Deleted Successfully";
	}

	@Override
	public String updateEmployee(Employee employee) {
		entityManager.merge(employee);
		return "Employee Updated Successfully";
	}

	@Override
	public List<Employee> getAllEmployee() {
		TypedQuery<Employee> employees=entityManager.createQuery("select e from Employee e",Employee.class);
	List<Employee> listOfEmps=employees.getResultList();
	return listOfEmps;
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	

}
