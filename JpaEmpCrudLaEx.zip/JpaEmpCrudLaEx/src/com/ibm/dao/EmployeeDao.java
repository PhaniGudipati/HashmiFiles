package com.ibm.dao;

import java.util.List;

import com.ibm.entity.Employee;

public interface EmployeeDao {
	public abstract Employee getEmployeeById(int id);
	public abstract String addEmployee(Employee employee);
	public abstract String removeEmployee(Employee employee);
	
	public abstract String updateEmployee(Employee employee);
	public abstract List<Employee> getAllEmployee();
	public abstract void commitTransaction();
	public abstract void beginTransaction();
}
