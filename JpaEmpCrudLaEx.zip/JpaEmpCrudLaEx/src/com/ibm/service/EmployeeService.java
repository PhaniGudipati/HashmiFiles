package com.ibm.service;

import java.util.List;

import com.ibm.entity.Employee;

public interface EmployeeService {
	public abstract String addEmployee(Employee employee);
	public abstract String updateEmployee(Employee employee);
	public abstract String removeEmployee(Employee employee);
	public abstract Employee findEmployeeById(int id);
	public abstract List<Employee> getAllEmployee();
	

}
