package com.ibm.service;

import java.util.List;

import com.ibm.dao.EmployeeDao;
import com.ibm.dao.EmployeeDaoImpl;
import com.ibm.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao dao;

	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
	}

	@Override
	public String addEmployee(Employee employee) {
		dao.beginTransaction();
		String result = dao.addEmployee(employee);
		dao.commitTransaction();
		return result;
	}

	@Override
	public String updateEmployee(Employee employee) {
		dao.beginTransaction();
		String result = dao.updateEmployee(employee);
		dao.commitTransaction();
		return result;
	}

	@Override
	public String removeEmployee(Employee employee) {
		dao.beginTransaction();
		String result = dao.removeEmployee(employee);
		dao.commitTransaction();
		return result;
	}

	@Override
	public Employee findEmployeeById(int id) {
		// TODO Auto-generated method stub
		Employee employee = dao.getEmployeeById(id);
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		return dao.getAllEmployee();
	}

}
