package com.ibm.client;

import java.util.List;
import java.util.Scanner;

import com.ibm.entity.Employee;
import com.ibm.service.EmployeeService;
import com.ibm.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		EmployeeService service=new EmployeeServiceImpl();
		Scanner scanner=new Scanner(System.in);
		Employee emp=null;
		String result=null;
		while(true) {
			System.out.println("Employee Management Apllication");
			System.out.println("*******************************");
			System.out.println("Choose an Option");
			System.out.println("1.Add Employee \n2.Select Employee \n3.Update Employee \n.4Delete Employee \n5.Get All Employees");
			int option=scanner.nextInt();
			switch(option) {
			case 1:
				System.out.println("Enter Your empNum");
				int empId=scanner.nextInt();
				System.out.println("Enter Your Name");
				String empName=scanner.next();
				System.out.println("Enter your Saalary");
				int empSal=scanner.nextInt();
				System.out.println("Enter your Address");
				String empAdd=scanner.next();
				emp=new Employee(empId,empName,empSal,empAdd);
				result=service.addEmployee(emp);
				System.out.println(result);
				break;
			case 2:
				System.out.println("Enter empId");
				int empId1=scanner.nextInt();
				Employee employee=service.findEmployeeById(empId1);
				System.out.println(employee);
				break;
			case 3:
				System.out.println("Enter Your EmpNumber");
				empId=scanner.nextInt();
				System.out.println("Enter Your Name");
				empName=scanner.next();
				System.out.println("Enter Your Salary");
				empSal=scanner.nextInt();
				System.out.println("Enter Your Address");
				empAdd=scanner.next();
				emp=new Employee(empId,empName,empSal,empAdd);
				result=service.updateEmployee(emp);
				System.out.println(result);
				break;
			case 4:
				System.out.println("Enter Your EmpId");
				empId1=scanner.nextInt();
				result=service.removeEmployee(service.findEmployeeById(empId1));
				System.out.println(result);
				break;
			case 5:
				List<Employee> empsResult=service.getAllEmployee();
				for(Employee emp1:empsResult) {
					System.out.println(emp1);
				}
				break;
			}
		}
		
		

	}

}
