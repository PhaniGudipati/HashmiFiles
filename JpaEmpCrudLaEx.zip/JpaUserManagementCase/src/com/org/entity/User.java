package com.org.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="UserManagementTable")
public class User {
	@Id
	private int uid;
	private String uname;
	private int uSal;
	private String address;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getuSal() {
		return uSal;
	}
	public void setuSal(int uSal) {
		this.uSal = uSal;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(int uid, String uname, int uSal, String address) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.uSal = uSal;
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", uSal=" + uSal + ", address=" + address + "]";
	}
	
	
	

}
