package com.org.service;

import java.util.List;

import com.org.entity.User;

public interface UserService {
	public abstract String addUser(User user);
	public abstract String updateUser(User user);
	public abstract String removeUser(User user);
	public abstract User findUserById(int id);
	public abstract List<User> getAllUser();

}
