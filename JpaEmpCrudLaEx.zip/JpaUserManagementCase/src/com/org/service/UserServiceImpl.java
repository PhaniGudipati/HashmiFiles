package com.org.service;

import java.util.List;

import com.org.dao.UserDao;
import com.org.dao.UserDaoImpl;
import com.org.entity.User;

public class UserServiceImpl implements UserService {
	private UserDao dao;
	
	public UserServiceImpl() {
		dao=new UserDaoImpl();
	}

	@Override
	public String addUser(User user) {
		dao.beginTransaction();
		String result=dao.addUser(user);
		dao.commitTransaction();
		
		return result;
	}

	@Override
	public String updateUser(User user) {
		
		dao.beginTransaction();
		String result=dao.updateUser(user);
		dao.commitTransaction();
		
		return result;
	}

	@Override
	public String removeUser(User user) {
		dao.beginTransaction();
		String result=dao.removeUser(user);
		dao.commitTransaction();
		
		return result;
		
	}

	@Override
	public User findUserById(int id) {
		User user=dao.findUserById(id);
		
		return user;
	}

	@Override
	public List<User> getAllUser() {
		return dao.getAllUser();
	}

	
}
