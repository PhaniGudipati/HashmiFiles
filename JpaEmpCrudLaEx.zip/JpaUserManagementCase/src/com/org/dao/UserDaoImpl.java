package com.org.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.org.entity.User;

public class UserDaoImpl implements UserDao{
	private EntityManager entityManager;
	public UserDaoImpl() {
		entityManager=JpaUtil.getEntityManager();
	}

	@Override
	public String addUser(User user) {
		entityManager.persist(user);
		return "User Added Successfully";
	}

	@Override
	public String updateUser(User user) {
		entityManager.merge(user);
		return "User Updated Successfully";
	}

	@Override
	public String removeUser(User user) {
		entityManager.remove(user);
		return "user deleted successfully";
	}

	@Override
	public User findUserById(int id) {
		User user=entityManager.find(User.class, id);
		return user;
	}

	@Override
	public List<User> getAllUser() {
		TypedQuery<User> users=entityManager.createQuery("select u from User u",User.class);;
		return null;
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
	entityManager.getTransaction().begin();
		
	}

}
