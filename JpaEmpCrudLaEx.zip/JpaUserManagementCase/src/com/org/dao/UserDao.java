package com.org.dao;

import java.util.List;

import com.org.entity.User;

public interface UserDao {
	public abstract String addUser(User user);
	public abstract String updateUser(User user);
	public abstract String removeUser(User user);
	public abstract User findUserById(int id);
	public abstract List<User> getAllUser();
	public abstract void commitTransaction();
	public abstract void beginTransaction();
	

}
