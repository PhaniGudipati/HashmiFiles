package com.org.client;

import java.util.List;
import java.util.Scanner;

import com.org.entity.User;
import com.org.service.UserService;
import com.org.service.UserServiceImpl;

public class TestClient {

	public static void main(String[] args) {
		UserService service=new UserServiceImpl();
		Scanner scanner=new Scanner(System.in);
		User user=null;
		String result=null;
		while(true) {
		System.out.println("User Mnagement");
		System.out.println("*************************************");
		System.out.println("Choose an Option");
		System.out.println("1.Add User\n2.select User \n3.Update User \n 4.Delete User \n5.Get All Users");
		int option=scanner.nextInt();
		switch(option) {
		case 1:
			System.out.println("Enter your userId");
			int uid=scanner.nextInt();
			System.out.println("Enter your Name");
			String uname=scanner.next();
			System.out.println("Enter your user salary");
			int uSal=scanner.nextInt();
			System.out.println("Enter your address");
			String address=scanner.next();
			user=new User(uid, uname, uSal, address);
			result=service.addUser(user);
			System.out.println(result);
			break;
		case 2:
			System.out.println("enter user id");
			int uid1=scanner.nextInt();
			User userr=service.findUserById(uid1);
			System.out.println(userr);
			break;
		case 3:
			System.out.println("Enter your userId");
			 uid=scanner.nextInt();
			System.out.println("Enter your Name");
			 uname=scanner.next();
			System.out.println("Enter your user salary");
		 uSal=scanner.nextInt();
			System.out.println("Enter your address");
			 address=scanner.next();
			 user=new User(uid, uname, uSal, address);
			 result=service.updateUser(user);
			 System.out.println(result);
		break;
		case 4:
			System.out.println("Enter user Id");
			uid1=scanner.nextInt();
			result=service.removeUser(service.findUserById(uid1));
			System.out.println(result);
			break;
		case 5:
		List<User> usersResult=service.getAllUser();
		for(User user1: usersResult) {
			System.out.println(user1);
		}
		break;
		
			
			
		}
			
			
			
			
		}

	}

}
