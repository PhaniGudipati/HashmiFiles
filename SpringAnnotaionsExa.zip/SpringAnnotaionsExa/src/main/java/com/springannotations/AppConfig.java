package com.springannotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan(basePackages = {"com.springannotations"})
public class AppConfig {
	@Bean("employee")
	public Employee getEmployee() {
		Employee emp=new Employee();
		emp.setId(123);
		emp.setName("Phani");
		emp.setAddress(getAddress());
		return emp;
	}
	@Bean
	public Address getAddress() {
		Address address=new Address();
		address.setCity("Hydearabad");
		address.setColony("Hitech");
		address.setHno(1234);
		return address;
	}
	

}
