package com.springannotations;

import org.springframework.stereotype.Component;

//@Component
public class Address {
	private int hno;
	private String city;
	private String colony;
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public Address(int hno, String city, String colony) {
		super();
		this.hno = hno;
		this.city = city;
		this.colony = colony;
	}
	@Override
	public String toString() {
		return "Address [hno=" + hno + ", city=" + city + ", colony=" + colony + "]";
	}

}
